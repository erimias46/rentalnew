<?php 
    $redirect_link = "../../";
    $side_link = "../../";
    include '../../include/nav.php'; 
    $current_date = date('Y-m-d');
?>

<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <h4 class="card-title">Unit Banner</h4>
                            </div>
                            <div class="col-lg-6">
                                <div class="float-end">
                                    <button class="btn btn-success btn-rounded" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fas fa-plus"></i> Add Unit Banner</button>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="table-responsive">
                            <table id="zero_config" class="table border table-striped table-bordered text-nowrap">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Unit Banner Name</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                        <tbody>
                                            <?php
                                                $sql = "SELECT * FROM unitbanner";
                                                $result = mysqli_query($con, $sql);
                                                while ($row = mysqli_fetch_assoc($result)){
                                            ?>
                                                <tr>
                                                    <td><?php echo $row['unitbanner_id'];?></td>
                                                    <td><?php echo $row['unitbanner_name'];?></td>
                                                    <td><?php echo $row['price'];?></td>
                                                    <td>
                                                        <button class="btn btn-warning btn-rounded" data-bs-toggle="modal" data-bs-target="#edit<?php echo $row['unitbanner_id'];?>"><i class="fas fa-pencil-alt"></i> Edit</button>
                                                        <a href="remove.php?id=<?php echo $row['unitbanner_id'];?>&from=unitbanner" class="btn btn-danger btn-rounded btn-del"><i class="fas fa-trash-alt"></i> Delete</a>
                                                    </td>
                                                </tr>
                                                <!-------------------------------------------------- Modal ------------------------------------->
                                                <div class="modal fade" id="edit<?php echo $row['unitbanner_id'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <form method="post">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Edit Unit Banner</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <input type="hidden" name="unitbanner_id" class="form-control" value="<?php echo $row['unitbanner_id']; ?>">
                                                                        <div class="form-group mb-3">
                                                                            <label class="form-label">Unit Banner Name </label>
                                                                            <input type="text" name="unitbanner_name" class="form-control" value="<?php echo $row['unitbanner_name']; ?>">
                                                                        </div>
                                                                        <div class="form-group mb-3">
                                                                            <label class="form-label">Price </label>
                                                                            <input type="text" name="price" class="form-control" value="<?php echo $row['price']; ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                    <button type="submit" name="update_unitbanner" class="btn btn-primary">Update</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php 
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 

    <!-------------------------------------------------- Modal ------------------------------------->

            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <form method="post">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add Unit Banner</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="form-group mb-3">
                                        <label class="form-label">Unit Banner Name </label>
                                        <input type="text" name="unitbanner_name" class="form-control">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label class="form-label">Price </label>
                                        <input type="text" name="price" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="add_unitbanner" class="btn btn-primary">Add</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            
        </div>
    </div>
</div>


<?php
    include '../../include/footer.php';
?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php
$status = $_GET['status'];
if (isset($status)) {
    if ($status == "success") {
        ?>
            <script>
                swal("Great!", "Task Done", "success");
            </script>
        <?php
    } else {
        ?>
            <script>
                swal("Opps!", "Have an error please contact admin", "error");
            </script>
        <?php
    }
}

if (isset($_POST['add_unitbanner'])) {
    $unitbanner_name = $_POST['unitbanner_name'];
    $price = $_POST['price'];

    $add_unitbanner = "INSERT INTO unitbanner(unitbanner_name, price) VALUES ('$unitbanner_name', '$price')";
    $result_add = mysqli_query($con, $add_unitbanner);

    if ($result_add) {
        echo "<script>window.location = 'action.php?status=success&redirect=unit_banner.php'; </script>";
    } else {
        echo "<script>window.location = 'action.php?status=error&redirect=unit_banner.php'; </script>";
    }
}

if (isset($_POST['update_unitbanner'])) {
    $unitbanner_id = $_POST['unitbanner_id'];
    $unitbanner_name = $_POST['unitbanner_name'];
    $price = $_POST['price'];

    $unitbanner_update = "UPDATE `unitbanner` SET unitbanner_name = '$unitbanner_name', price = '$price' WHERE unitbanner_id = '$unitbanner_id'"; 
    $result_update = mysqli_query($con, $unitbanner_update);

    if ($result_update) {
        echo "<script>window.location = 'action.php?status=success&redirect=unit_banner.php'; </script>";
    } else {
        echo "<script>window.location = 'action.php?status=error&redirect=unit_banner.php'; </script>";
    }
}

?>

<script>
    $('.btn-del').on('click', function(e){
        e.preventDefault();
        const href = $(this).attr('href')

        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this data!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                document.location.href = href;
            } else {
                
            }
        }) 
    });
</script>