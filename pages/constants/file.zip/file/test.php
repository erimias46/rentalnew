<?php

    include '../../../include/db.php';

?>


<!DOCTYPE html>
<html>
<head>
	<title>Select Option Form</title>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
	<form>
		<select id="selectOption">
			<option value="">--Select--</option>
            <?php
                for ($i == 1; $i <= 20; $i++) {
                    ?>
                        <option value="<?php echo $i?>">Option <?php echo $i?></option>
                    <?php
                }
            ?>
		</select>
	</form>

	<div id="inputForm"></div>

	<script>
		$(document).ready(function() {
			$('#selectOption').change(function() {
				var optionValue = $(this).val();
				if (optionValue) {
					var inputForm = '<form>';
					var inputCount = optionValue * 1;
					for (var i = 1; i <= inputCount; i++) {
						inputForm += '<label>Table ' + i + ' Input ' + i + '</label><br>';
						inputForm += '<input type="text" name="table_' + i + '_input_' + i + '"><br>';
                        inputForm += '<select><option value="">--Select--</option></select>';
					}
					inputForm += '</form>';
					$('#inputForm').html(inputForm);
				} else {
					$('#inputForm').empty();
				}
			});
		});
	</script>
</body>
</html>
