<?php 
    $redirect_link = "../../";
    $side_link = "../../";
    include '../../include/nav.php'; 
    $current_date = date('Y-m-d');
?>

<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title"> Add Constants </h4>
                        <div class="form-body">
                            <form action="" method="POST">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label class="form-label">Page Display Name </label>
                                            <input type="text" name="page_name" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label class="form-label">Table Name </label>
                                            <input type="text" name="table_name" class="form-control" required> 
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label class="form-label"> Choose Number of Columns </label>
                                        <div class="input-group mb-3">                                            
                                            <select name="column_no" id="selectOption" class="form-select" id="inputGroupSelect04">
                                                <?php
                                                    for ($i == 1; $i <= 20; $i++) {
                                                        ?>
                                                            <option value="<?php echo $i?>"><?php echo $i?> Columns</option>
                                                        <?php
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                
                                    <div id="inputForm"></div>

                                <script>
                                    $(document).ready(function() {
                                        $('#selectOption').change(function() {
                                            var optionValue = $(this).val();
                                            if (optionValue) {
                                                var inputForm = '<div class="row">';
                                                var inputCount = optionValue * 1;
                                                for (var i = 1; i <= inputCount; i++) {
                                                    inputForm += '<div class="col-md-6"><div class="form-group mb-3">';
                                                    inputForm += '<label class="form-label">Column Name </label>';
                                                    inputForm += '<input type="text" name="column[]" class="form-control" required>';
                                                    inputForm += '</div></div>';

                                                    inputForm += '<div class="col-md-6"><div class="form-group mb-3">';
                                                    inputForm += '<label class="form-label"> Type </label>';
                                                    inputForm += '<select name="column_type[]" class="form-select" id="inputGroupSelect04" required>';
                                                    inputForm += '<option value="INT"> Int</option>';
                                                    inputForm += '<option value="TEXT"> Text</option>';
                                                    inputForm += '<option value="DATE"> Date</option>';
                                                    inputForm += '</select>';
                                                    inputForm += '</div></div>';
                                                }
                                                inputForm += '</div>';
                                                $('#inputForm').html(inputForm);
                                            } else {
                                                $('#inputForm').empty();
                                            }
                                        });
                                    });
                                </script>
                               
                                <div class="form-actions">
                                    <div class="text-end">
                                        <button name="add" type="submit" class="btn btn-success btn-rounded"><i class="fas fa-plus"></i> Add</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Test Result-->
        <?php
        if (isset($_POST['add'])) {

            // POST methods
            $page_name = $_POST['page_name'];
            $table_name = $_POST['table_name'];
            $column_no = $_POST['column_no'];
            $column_types = $_POST['column_type'];
            $columns = $_POST['column'];
            $current_date = date('Y-m-d');

            // Create table
			$sql = "CREATE TABLE $table_name (";
			$sql .= "$columns[0] $column_types[0] PRIMARY KEY AUTO_INCREMENT,";
			for ($i = 1; $i < count($columns); $i++) {
				$sql .= "$columns[$i] $column_types[$i],";
			}
			$sql = rtrim($sql, ",");
			$sql .= ")";
            $result = mysqli_query($con, $sql);

            // set sql
            $constants = "INSERT INTO d_constants(name, db, date) VALUES ('$page_name', '$table_name', '$current_date')";
            $c_result = mysqli_query($con, $constants);

            if ($result && $c_result) {
                echo "<script>window.location = 'action.php?status=success&redirect=add.php'; </script>";
            } else {
                echo "<script>window.location = 'action.php?status=error&redirect=add.php'; </script>";
            }
        }
        ?>

    </div>
</div>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php
$status = $_GET['status'];
if (isset($status)) {
    if ($status == "success") {
        ?>
            <script>
                swal("Great!", "Task Done", "success");
            </script>
        <?php
    } else {
        ?>
            <script>
                swal("Opps!", "Have an error please contact admin", "error");
            </script>
        <?php
    }
}

?>

<?php
    include '../../include/footer.php';
?>